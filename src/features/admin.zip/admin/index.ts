export { adminRouteElements, adminRoutes } from "./routes";
export { AdminLayout, AdminLayoutWrapper } from "./layouts/AdminLayout";
export { AdminSidebar } from "./layouts/AdminSidebar";
export { AdminRouteGuard } from "./components/AdminRouteGuard";
export { AdminErrorBoundary } from "./components/AdminErrorBoundary";
export { StatCard } from "./components/StatCard";
export { useAdminNav, ADMIN_NAV } from "./hooks/useAdminNav";
export type { AdminNavItem, AdminNavSection } from "./hooks/useAdminNav";
export type { StatCardProps } from "./components/StatCard";
export {
  useAdminGameCatalog,
  getAdminGameCatalog,
  getAdminGameById,
  saveGameOverride,
  resetGameOverride,
  resetAllGameOverrides,
  filterAdminGames,
  getGameCatalogStats,
} from "./services/gameCatalogAdminService";
export type {
  AdminGameCatalogEntry,
  AdminGameFilter,
  GameCatalogOverride,
  GameCatalogStats,
} from "./services/gameCatalogAdminService";
